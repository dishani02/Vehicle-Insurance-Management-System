<div class="sidebar">
    <nav>
        <a href="admin-dashboard.php" class="menu-item">
            <h3>Dashboard</h3>
            <i class="fa-solid fa-chevron-right"></i>
        </a>

        <a href="admin-user-profile.php" class="menu-item">
            <h3>My Profile</h3>
            <i class="fa-solid fa-chevron-right"></i>
        </a>

        
    </nav>
</div>