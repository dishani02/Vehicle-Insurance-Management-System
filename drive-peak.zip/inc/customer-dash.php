<div class="sidebar">
    <nav>
        <a href="my-account-dashboard.php" class="menu-item">
            <h3>Dashboard</h3>
            <i class="fa-solid fa-chevron-right"></i>
        </a>

        <a href="my-user-profile.php" class="menu-item">
            <h3>User Profile</h3>
            <i class="fa-solid fa-chevron-right"></i>
        </a>

        <a href="my-vehicles.php" class="menu-item">
            <h3>My vehicles</h3>
            <i class="fa-solid fa-chevron-right"></i>
        </a>

        <a href="my-claim-history.php" class="menu-item">
            <h3>Claims & Payments <br> History</h3>
            <i class="fa-solid fa-chevron-right"></i>
        </a>

        <a href="my-policies.php" class="menu-item">
            <h3>Policies</h3>
            <i class="fa-solid fa-chevron-right"></i>

        <a href="my-payments.php" class="menu-item">
             <h3>Payments</h3>
             <i class="fa-solid fa-chevron-right"></i>
        </a>
    </nav>
</div>