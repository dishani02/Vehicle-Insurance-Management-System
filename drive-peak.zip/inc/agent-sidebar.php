<div class="sidebar">
    <nav>
        <a href="agent-dashboard.php" class="menu-item">
            <h3>Dashboard</h3>
            <i class="fa-solid fa-chevron-right"></i>
        </a>

        <a href="agent-user-profile.php" class="menu-item">
            <h3>My Profile</h3>
            <i class="fa-solid fa-chevron-right"></i>
        </a>

        <a href="agent-coverage.php" class="menu-item">
            <h3>Coverage</h3>
            <i class="fa-solid fa-chevron-right"></i>
        </a>

        <a href="agent-reports.php" class="menu-item">
            <h3>Reports</h3>
            <i class="fa-solid fa-chevron-right"></i>
        </a>
    </nav>
</div>